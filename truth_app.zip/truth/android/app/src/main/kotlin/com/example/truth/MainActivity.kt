package com.example.truth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
